<?php
	
	header("Location: lobby.php");

?>
