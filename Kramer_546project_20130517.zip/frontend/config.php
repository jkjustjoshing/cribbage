<?php
	const BACKEND_DIRECTORY = "/Users/joshkramer/Documents/Schoolwork/546/project/backend/";
?>